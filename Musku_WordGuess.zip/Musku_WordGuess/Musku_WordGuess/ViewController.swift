//
//  ViewController.swift
//  Musku_WordGuess
//
//  Created by Musku,Varun Reddy on 3/27/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    @IBOutlet weak var wordsMissedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    @IBOutlet weak var guessletter: UIButton!
    
    @IBOutlet weak var playAgain: UIButton!
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    var words = [["java", "Programming Language"],
               ["Tiger", "Animal"],
               ["Bike", "Two wheeler"],
                 ["Fruit","Apple"],["heart","lubdub"]]
    
    var images = ["java","tiger","Bike","Apple","Heart","TryAgain"]
    
    
    var count = 0
        var lettersGuessed = ""
        var word = ""
        var inc = 0
        var maxNumOfWrongGuesses = 10
        var str1 = ""
        var str2 = ""
        var str3 = ""
        var c1 = 0
        var c2 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        wordsGuessedLabel.text! += int (count)
        guessletter.isEnabled = false
              word = words[count][0]
              userGuessLabel.text = ""
              str1 = wordsGuessedLabel.text!
              str2 = wordsMissedLabel.text!
              str3 = wordsRemainingLabel.text!
              totalWordsLabel.text = totalWordsLabel.text!+String(words.count)
              wordsGuessedLabel.text = str1+String(count)
              wordsRemainingLabel.text = str3+String(words.count)
              wordsMissedLabel.text = str2+String(count)
              
              updateUnderscores();
              
              hintLabel.text = "Hint: "+words[count][1]
    }

    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
     
        var letter = guessLetterField.text!
                //guessLetterField.resignFirstResponder()
                lettersGuessed = lettersGuessed + letter
                var revealedWord = ""
                for l in word{
                    if lettersGuessed.contains(l){
                        revealedWord += "\(l)"
                    }
                    else{
                        revealedWord += "_ "
                    }
                    
                }
                inc = inc + 1
                guessCountLabel.text = "You have made \(inc)  Guesses";
                maxNumOfWrongGuesses = maxNumOfWrongGuesses - 1
                userGuessLabel.text = revealedWord
                guessLetterField.text = ""
                if (userGuessLabel.text!.contains("_") == false){
                    count += 1
                    guessCountLabel.text = "You won! it took you \(inc) attemps to guess the word!";
                    guessLetterField.isEnabled = false
                    c1 = c1 + 1
                    wordsGuessedLabel.text = str1+String(c1)
                    wordsMissedLabel.text = str2+String(c2)
                    wordsRemainingLabel.text = str3+String((words.count) - count)
                    maxNumOfWrongGuesses = 10
                    inc = 0
                    playAgain.isHidden = false;
                    guessletter.isEnabled = false;
                    imageView.image = UIImage(named: images[count-1])
                    if (count == words.count){
                        guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                        c1 = 0
                        c2 = 0
                        count = 0
                    }
                    
                }
                if(maxNumOfWrongGuesses == 0 && userGuessLabel.text!.contains("_") == true){
                    count += 1
                    inc = 0
                    c2 = c2 + 1
                    guessCountLabel.text = "You are out of all guesses. Try again?";
                    guessLetterField.isEnabled = false
                    wordsGuessedLabel.text = str1+String(c1)
                    wordsMissedLabel.text = str2+String(c2)
                    wordsRemainingLabel.text = str3+String((words.count) - count)
                    maxNumOfWrongGuesses = 10
                    playAgain.isHidden = false;
                    guessletter.isEnabled = false;
                    imageView.image = UIImage(named: images[5])
                    if (count == words.count){
                        guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                        c1 = 0
                        c2 = 0
                        count = 0
                    }
                }
        guessletter.isEnabled = false
               
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
        playAgain.isHidden = true
                imageView.image = UIImage(named: "")
                lettersGuessed = ""
                wordsRemainingLabel.text = str3+String((words.count) - count)
                if(count == 0){
                    word = words[count][0]
                    userGuessLabel.text = ""
                    updateUnderscores()
                    guessLetterField.isEnabled = true
                    hintLabel.text = "Hint: "
                    hintLabel.text! += words[count][1]
                    wordsGuessedLabel.text = str1+String(c1)
                    wordsMissedLabel.text = str2+String(c2)
                    wordsRemainingLabel.text = str3+String((words.count) - count)
                    guessCountLabel.text = "You have made \(inc)  Guesses";
                }
                else{
                    word = words[count][0]
                    guessCountLabel.text = "You have made \(inc)  Guesses";
                    guessLetterField.isEnabled = true
                    //fetch the hint related to the word
                    hintLabel.text = "Hint: "
                    hintLabel.text! += words[count][1]
                    //Enabling the check button.
                    guessletter.isEnabled = false
                    userGuessLabel.text = ""
                    updateUnderscores()
                }
               
        
        
    }
    
    @IBAction func guessTextAction(_ sender: UITextField) {
        var textEnterd = guessLetterField.text!;
        textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEnterd
        
        if textEnterd.isEmpty{
            guessletter.isEnabled = false
        }
        else{
            guessletter.isEnabled = true
        }
    }
    
    func updateUnderscores(){
            for letter in word{
                userGuessLabel.text! += "_ "
            }
        }
}

