//
//  MovieData.swift
//  Musku_Movies
//
//  Created by student on 4/25/22.
//

import Foundation

import UIKit

struct Movies {
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast:[String] = []
}

struct Genre {
    var category:String
    var movies:[Movies] = []
}

let movie1 = Genre(category: "Drama",
                   movies: [
                    Movies(title: "RRR", image: UIImage(named: "Rrr")!, releasedYear: "2022", movieRating: "9.5", boxOffice: "1100 M", moviePlot: "About two persons friendship and how they acheived their common goal", cast: ["NTR","Ramcharan","Alia Bhatt,Akshay Kumar"]),
                    Movies(title: "Pushpa", image: UIImage(named: "Pushpa")!, releasedYear: "2022", movieRating: "9.7", boxOffice: "320 M", moviePlot: " A peson become more poular in and become don for illegal bussiness", cast: ["Allu Arjun","Rashmika","Shikawath"]),
                    Movies(title: "Dhruva", image: UIImage(named: "Dhruva")!, releasedYear: "2021", movieRating: "9.0", boxOffice: "120.1M", moviePlot: "A police who fight with the businessman who has reputation in the society", cast: ["Ram Charan","Rakul Preeth","Arvind Swamy"]),
                    Movies(title: "Bahubali", image: UIImage(named: "Bahu")!, releasedYear: "2022", movieRating: "8.5", boxOffice: "220.1M", moviePlot: "A person coming fighting for his friend village and saving it from Gangsters", cast: ["Prabhas","Rana","Anushka", "Thammana"]),
                    Movies(title: "24", image: UIImage(named: "24")!, releasedYear: "2022", movieRating: "9.1", boxOffice: "420.1M", moviePlot: "A Scientist invent a watch which will take person to 24 hours future", cast: ["Surya","NithyaMinon",])])

let movie2 = Genre(category: "Horror",
                   movies: [
                    Movies(title: "Dhayam", image: UIImage(named: "Dhayam")!, releasedYear: "2019", movieRating: "5", boxOffice: "17 M", moviePlot: "Eight people enter a room in a company for an interview for the post of CEO. The room has no windows, the walls are white, and there is a clock attached to one side. There are five men and three women. The men include one smart guy in white, one villain in full black, one coward who always bites his nails, one clairvoyant guy who always laughs like a fool, and one tall guy who wears a mask.", cast: ["Sanjeev","Irra Agarwal","Santhosh"]),
                    Movies(title: "Pegvin", image: UIImage(named: "Pegvin")!, releasedYear: "2013", movieRating: "8.7", boxOffice: "10 M", moviePlot: "Rhythm, a young woman who resides in Kodaikanal, is happily married to her husband Gautham and is eight months pregnant. Despite living a life of happiness, she is traumatised by frequent nightmares of a child being harmed by a man wearing a Charlie Chaplin mask.", cast: ["Keerthy Suresh ","Madhampatty Rangaraj","Mathi "]),
                    Movies(title: "Arundhati", image: UIImage(named: "AA")!, releasedYear: "2015", movieRating: "9.3", boxOffice: "60.7M", moviePlot: "A lady saving her kingdom from a brutal Man", cast: ["Anushka","Sonu Sood","Shindey"]),
                    Movies(title: "Ekkadiki Pothavu Chinnavada", image: UIImage(named: "Epcv")!, releasedYear: "2016", movieRating: "8.9", boxOffice: "13 M", moviePlot: "Arjun, after finishing his exam, waits at marriage registrar office for his girlfriend Ayesha to arrive and marry her, but Ayesha does not show up, leaving Arjun heartbroken. A few years later, Kishore, a cousin of Arjun's friend, becomes", cast: ["Nikhil","hebba Patel","Vennala Kishor"]),
                    Movies(title: "Nun", image: UIImage(named: "Nun")!, releasedYear: "2013", movieRating: "7.5", boxOffice: "130.4M", moviePlot: "The Nun is a 2018 American gothic supernatural horror film directed by Corin Hardy and written by Gary Dauberman, from a story by Dauberman and James Wan.[2][3] It is a spin-off/prequel of 2016's The Conjuring 2 and the fifth installment in the Conjuring Universe franchise.", cast: ["Tissa","Fargima",])])

let movie3 = Genre(category: "Comedy",
                   movies: [
                    Movies(title: "F3", image: UIImage(named: "F3")!, releasedYear: "2019", movieRating: "9.1", boxOffice: "500M", moviePlot: "In Hungary, Venky and Varun are caught by police. As they are interrogated by Indian Embassy officer Viswanath, Venky begins narrates his past. Venky works as a PA to local MLA in Hyderabad but earns handsomely. He marries Harika, a software engineer, who he met through a marriage proposal. At first, his life was enjoyable but Harika takes advantage of Venky's innocence and starts tormenting him. Harika's sister, Honey, enters their home and creates more trouble between Harika and Venky to stay at their house.", cast: ["Varun Tej","Venky","Thammana"]),
                    Movies(title: "Gabbar Singh", image: UIImage(named: "Gabbar")!, releasedYear: "2012", movieRating: "9.3", boxOffice: "75.6M", moviePlot: "Gabbar Singh is a 2012 Indian Telugu-language action comedy film directed by Harish Shankar and produced by Bandla Ganesh under Parameswara Art Productions. The film stars Pawan Kalyan and Shruti Haasan while Abhimanyu Singh, Ajay, Suhasini Maniratnam, Nagineedu and Kota Srinivasa Rao play supporting roles.", cast: ["Pawan Kalyan","Shruthi ","Brahmanandam"]),
                    Movies(title: "Oye", image: UIImage(named: "oy")!, releasedYear: "2008", movieRating: "8.7", boxOffice: "40.5M", moviePlot: "Oye! is a 2009 Indian Telugu-language romantic drama film written and directed by debutanat Anand Ranga. The film stars Siddharth and Shamili (in her first leading role),[1] while Sunil and Ali play supporting roles. The music of the film was composed by Yuvan Shankar Raja.", cast: ["Siddartha","M.S Naraya","Shamili"]),
                    Movies(title: "Nuv Naku Nachav", image: UIImage(named: "NNN")!, releasedYear: "2001", movieRating: "9.8", boxOffice: "90M", moviePlot: "Nuvvu Naaku Nachav (transl. I like you) is a 2001 Indian Telugu-language romantic comedy film directed by K. Vijaya Bhaskar who co-wrote the film with Trivikram Srinivas. It is produced by Sravanthi Ravi Kishore under the Sri Sravanthi Movies studio", cast: ["Venky","Brahmanandam","Arthi Agrawal"]),
                    Movies(title: "Dhee", image: UIImage(named: "Dhee")!, releasedYear: "2011", movieRating: "8.9", boxOffice: "45M", moviePlot: "A intelligent boy who loves Villian sister", cast: ["Manchu Vishnu","Jenelia","Sri Hari"])])



let moviesCollection = [movie1,movie2,movie3]
