//
//  ViewController.swift
//  Musku_SearchApp
//
//  Created by student on 2/28/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOption: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevImage: UIButton!
    
    @IBOutlet weak var nextImage: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var resetButton: UIButton!
    
    
    var topic:Int = -1
    var imgnum = 0
    
    var count1:Int = -1
    
    var arr =
          [["Actor01","Actor02","Actor03","Actor04","Actor05"],["Animal01","Animal02","Animal03","Animal04","Animal05"],["Flower01","Flower02","Flower03","Flower04","Flower05"]]
    
    var actor_keywords = ["actor","movie","hero","film"]
    var animal_keywords = ["animals","breed","domestic","wildanimals"]
    var flower_keywords = ["Flowers","plants","trees","scent"]
    
    var topics_array = [["Konidela Ram Charan Teja is an Indian actor, producer and entrepreneur who works predominantly in Telugu cinema. One of the highest-paid actors in India.","Uppalapati Venkata Suryanarayana Prabhas Raju, known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema.","Pawan Kalyan is an Indian actor, director, screenwriter, stunt coordinator, philanthropist, and politician.","Sushant Singh Rajput was an Indian actor known for his work in Hindi cinema. He starred in a number of commercially successful Bollywood films such as M.S. Dhoni: The Untold Story, Kedarnath and Chhichhore.","Ghattamaneni Mahesh Babu is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema."],
        ["The lion is a large cat of the genus Panthera native to Africa and India. It has a muscular, deep-chested body, short, rounded head, round ears, and a hairy tuft at the end of its tail. It is sexually dimorphi; ","Elephants are the largest existing land animals. Three living species are currently recognised: the African bush elephant, the African forest elephant, and the Asian elephant.","Monkey is a common name that may refer to most mammals of the infraorder Simiiformes, also known as the simians.","The tiger is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside.","The leopard is one of the five extant species in the genus Panthera, a member of the cat family, Felidae. "],
        ["A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears.","Hyacinthus is a small genus of bulbous, spring-blooming perennials.","Dianthus caryophyllus, commonly known as the carnation or clove pink, is a species of Dianthus. It is probably native to the Mediterranean region but its exact range is unknown due to extensive cultivation for the last 2,000 years.","Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. Lilies are a group of flowering plants which are important in culture and literature in much of the world.","Alstroemeria, commonly called the Peruvian lily or lily of the Incas, is a genus of flowering plants in the family Alstroemeriaceae. "]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        searchOption.isEnabled = false
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetButton.isHidden = true
        resultImage.image = UIImage(named: "default")
    }
    

    @IBAction func searchFieldAction(_ sender: Any) {
        searchOption.isEnabled = true
    }
    
    func buttonDisable()
    {
        nextImage.isHidden = false
        prevImage.isHidden = false
        resetButton.isHidden = false
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if (actor_keywords.contains(searchTextField.text!)){
            topic = 0
            imgnum = 0
            buttonDisable()
            }
        else if (animal_keywords.contains(searchTextField.text!)){
            topic = 1
            imgnum = 0
            buttonDisable()
        }
        
        else if (flower_keywords.contains(searchTextField.text!)){
            topic = 2
            imgnum = 0
            buttonDisable()
        }
       
        else {
            topic = -1
            resultImage.image = UIImage(named: "default")
            prevImage.isHidden = true
            nextImage.isHidden  = true
            resetButton.isHidden = true
            topicInfoText.text = ""
        }
        if (topic != -1){
            prevImage.isEnabled = false
            nextImage.isEnabled = true
            count1 = arr[topic].count
            resultImage.image = UIImage(named: arr[topic][0])
            topicInfoText.text = self.topics_array[topic][0]
            
        }
            
        
    }
    
    
    @IBAction func ShowNextImagesbtn(_ sender: UIButton) {
        
        prevImage.isEnabled = true
        imgnum += 1
        resultImage.image = UIImage(named: arr[topic][imgnum])
        topicInfoText.text = topics_array[topic][imgnum]
        if (imgnum == count1-1){
            nextImage.isEnabled = false
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        nextImage.isEnabled = true
        imgnum -= 1
        resultImage.image = UIImage(named: arr[topic][imgnum])
        topicInfoText.text = topics_array[topic][imgnum]
        if (imgnum == 0){
            prevImage.isEnabled = false
        }
    }
    

    @IBAction func resetButtonAction(_ sender: Any) {
        
        resultImage.image = UIImage(named: "default")
        prevImage.isHidden = true
        nextImage.isHidden = true
        topicInfoText.text = ""
        searchTextField.text = ""
        searchOption.isEnabled = false
        resetButton.isHidden = true
    }
    
   
}


